from certifi import where
print(where())
